Method is copied and modified from https://www.thegreenbutton.tv/forums/viewtopic.php?t=3760#p36116 by ViperBoy on thegreenbutton.tv
==========

This is for anyone getting the dreaded "Video playback device does not support playback of protected content" on Windows 7 or Windows 8 Media Center. One way to determine if your problem is a common DRM incompatibility is if that message appears, but you can minimize and then maximize Media Center to make the TV play, then this should work for you.

After hours of searching and trying every possible combination or steps from various FAQs and trial/error, I have finally found the set of steps that will reset DRM on both versions of Windows Media Center.

You must do this with an administrator account and Media Center closed.

3 key takeaways relative to other FAQs for those who have attempted this before
a) no need to manually rename or delete files in the DRM folder
b) no need to use the Micrsoft DRM web page - it won't work with Windows 8 at all and is not required for Windows 7
c) ResetDRM must be extracted and run manually

1) under control panel / folder options / view note your current settings and then
a) enable show hidden files, folders or drives
b) disable hide protected operating systems

2) Apply control panel changes but leave window open to reset at the end

3) open control panel / administrative tools / services and select "Windows Media Center Receiver Service". Stop the service

4) with Windows explorer remove the following files / folders
a) C:\ProgramData\Microsoft\PlayReady\mspr.hds
b) C:\ProgramData\Microsoft\PlayReady\cache
c) C:\ProgramData\Microsoft\eHome\mcendindiv.hds
d) C:\ProgramData\Microsoft\eHome\cache

5) DELETED

6) DELETED

7) use explorer to find cmd.exe at C:\Windows\System32

8 ) right click on cmd.exe and "run as administrator"

9) cd to the temp folder where you extracted ResetDRM.zip

10) run "CleanDRM.exe -v". A text window will open after a few seconds and verify that several files were removed. If there is an error that a resource could not be opened for exclusive access, you might need to reboot and try again after making sure that Media Center does not start automatically

11) exit cmd.exe

12) open Media Center

13) navigate to settings / TV / TV Signal / Update PlayReady

14) if Update PlayReady fails:
a) minimize Media Center without closing it
b) stop the Media Center Receiver service again
c) maximize Media Center
d) "try again" to update PlayReady

15) PlayReady should show a success page

16) go to TV Guide and attempt to watch a show

17) if everything went properly, you should be able to watch live TV

18 ) go back to control panel / folders and return the hidden/system file settings back to your original options